//
//  PlayerModel.swift
//  Cric_Tracker
//
//  Created by BJIT on 23/2/23.
//

import Foundation
struct PlayerModel: Codable{
    let data: [PlayerData]?
    
}
struct PlayerData: Codable{
    let resource: Resource?
    let id: Int?
    let fullname: String?
    let image_path: String?
    let updated_at: String?
    let dateofbirth: String?
    let battingstyle: String?
    let bowlingstyle: String?
    
    
}
