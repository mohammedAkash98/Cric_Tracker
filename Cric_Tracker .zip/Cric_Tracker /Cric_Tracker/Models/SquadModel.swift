//
//  SquadModel.swift
//  Cric_Tracker
//
//  Created by BJIT on 21/2/23.
//

import Foundation
struct SquadModel: Codable {
    let data: [SquadData]?
    
}
struct SquadData: Codable{
   
}

