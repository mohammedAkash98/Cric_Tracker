import Foundation
struct ScoreBoardModel: Codable{
    let data: MatchData1
}
struct MatchData1: Codable{
    let batting: [Batting]?
//    let bowling: [Bowling]?
//    let lineup: [LineupInfo]?
//    let runs: [RunScoreboard]?

}


//struct Batting: Codable {
   // let id,team_id: Int?
//    let active: Bool?
//    let player_id, ball, score: Int?
//    let four_x, six_x: Int?
//    let catch_stump_player_id: Int?
//    let runout_by_id, batsmanout_id: Int?
//    let bowling_player_id: Int?
//    let rate: Int?
//    let batsman: Batsman?
//    let result: OutStatus?

//}

// MARK: - Batsman
//struct RunScoreboard: Codable {
// 
//    let id, fixtureID, teamID, inning: Int?
//    let score, wickets: Int?
//    let overs: Double?
//
//    enum CodingKeys: String, CodingKey {
//        case  id
//        case fixtureID = "fixture_id"
//        case teamID = "team_id"
//        case inning, score, wickets, overs
//       
//    }
//}
//
//struct Batsman: Codable {
//    let id, country_id: Int?
//    let firstname, lastname, fullname: String?
//}
//
//// MARK: - Result
//struct OutStatus: Codable {
//    let name: String?
//
//}
//
//// MARK: - Bowling
//struct Bowling: Codable {
//    let id, sort, fixture_id, team_id: Int?
//    let active: Bool?
//    let player_id: Int?
//    let overs: Double?
//    let medians, runs, wickets, wide: Int?
//    let noball: Int?
//    let rate: Double?
//    let bowler: Batsman?
//}
//
//
//
//// MARK: - LineupElement
//struct LineupInfo: Codable {
//    let id, country_id: Int?
//    let firstname, lastname, fullname: String?
//    let image_path: String?
//    let dateofbirth: String?
//    let gender: String?
//    let battingstyle: String?
//    let bowlingstyle: String?
//    let position: Position?
//    let lineup: TeamPostion?
//}
//
//// MARK: - LineupLineup
//struct TeamPostion: Codable {
//    let team_id: Int?
//    let captain, wicketkeeper, substitution: Bool?
//}
