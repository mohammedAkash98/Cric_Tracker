// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)

import Foundation

// MARK: - Welcome
struct RecentMatch: Codable {
    let data: [MatchData]?
    let links: Links?
    let meta: Meta?

    enum CodingKeys: String, CodingKey {
        case data = "data"
        case links = "links"
        case meta = "meta"
    }
}

// MARK: - Datum
struct MatchData: Codable {
    let resource: DatumResource?
    let id: Int?
    let round: String?
    let localteamid: Int?
    let visitorteamid: Int?
    let startingAt: String?
    let type: TypeEnum?
    let status: Status?
    let note: String?
    let elected: Elected?
    let weatherReport: [JSONAny]?
    let league: League?
    let localteam: League?
    let visitorteam: League?
    let batting: [Batting]?
    let bowling: [Bowling]?
    let runs: [Run]?
    let lineup: [LineupElement]?
    let manofmatch: LineupElement?
    let tosswon: League?
    let venue: Venue?

    enum CodingKeys: String, CodingKey {
        case resource = "resource"
        case id = "id"
        case round = "round"
        case localteamid = "localteam_id"
        case visitorteamid = "visitorteam_id"
        case startingAt = "starting_at"
        case type = "type"
        case status = "status"
        case note = "note"
        case elected = "elected"
        case weatherReport = "weather_report"
        case league = "league"
        case localteam = "localteam"
        case visitorteam = "visitorteam"
        case batting = "batting"
        case bowling = "bowling"
        case runs = "runs"
        case lineup = "lineup"
        case manofmatch = "manofmatch"
        case tosswon = "tosswon"
        case venue = "venue"
    }
}

// MARK: - Batting
struct Batting: Codable {
    let resource: BattingResource?
    let id: Int?
    let teamid: Int?
    let ball: Int?
    let score: Int?
    let fourX: Int?
    let sixX: Int?
    let updatedAt: String?
    let batsman: LineupElement?

    enum CodingKeys: String, CodingKey {
        case resource = "resource"
        case id = "id"
        case teamid = "team_id"
        case ball = "ball"
        case score = "score"
        case fourX = "four_x"
        case sixX = "six_x"
        case updatedAt = "updated_at"
        case batsman = "batsman"
    }
}

// MARK: - LineupElement
struct LineupElement: Codable {
    let resource: LineupResource?
    let id: Int?
    let fullname: String?
    let imagePath: String?
    let dateofbirth: String?
    let updatedAt: String?
    let lineup: LineupLineup?

    enum CodingKeys: String, CodingKey {
        case resource = "resource"
        case id = "id"
        case fullname = "fullname"
        case imagePath = "image_path"
        case dateofbirth = "dateofbirth"
        case updatedAt = "updated_at"
        case lineup = "lineup"
    }
}

// MARK: - LineupLineup
struct LineupLineup: Codable {
    let teamid: Int?
    let captain: Bool?
    let wicketkeeper: Bool?
    let substitution: Bool?

    enum CodingKeys: String, CodingKey {
        case teamid = "team_id"
        case captain = "captain"
        case wicketkeeper = "wicketkeeper"
        case substitution = "substitution"
    }
}

enum LineupResource: String, Codable {
    case players = "players"
}

enum BattingResource: String, Codable {
    case battings = "battings"
}

// MARK: - Bowling
struct Bowling: Codable {
    let resource: BowlingResource?
    let id: Int?
    let teamid: Int?
    let overs: Double?
    let medians: Int?
    let runs: Int?
    let wickets: Int?
    let updatedAt: String?
    let bowler: LineupElement?

    enum CodingKeys: String, CodingKey {
        case resource = "resource"
        case id = "id"
        case teamid = "team_id"
        case overs = "overs"
        case medians = "medians"
        case runs = "runs"
        case wickets = "wickets"
        case updatedAt = "updated_at"
        case bowler = "bowler"
    }
}

enum BowlingResource: String, Codable {
    case bowlings = "bowlings"
}

enum Elected: String, Codable {
    case batting = "batting"
    case bowling = "bowling"
}

// MARK: - League
struct League: Codable {
    let resource: LeagueResource?
    let id: Int?
    let name: String?
    let code: String?
    let updatedAt: String?
    let imagePath: String?

    enum CodingKeys: String, CodingKey {
        case resource = "resource"
        case id = "id"
        case name = "name"
        case code = "code"
        case updatedAt = "updated_at"
        case imagePath = "image_path"
    }
}

enum LeagueResource: String, Codable {
    case leagues = "leagues"
    case teams = "teams"
}

enum DatumResource: String, Codable {
    case fixtures = "fixtures"
}

// MARK: - Run
struct Run: Codable {
    let resource: RunResource?
    let id: Int?
    let fixtureid: Int?
    let teamid: Int?
    let inning: Int?
    let score: Int?
    let wickets: Int?
    let overs: Double?
    let pp1: Pp1?
    let pp2: String?
    let pp3: JSONNull?
    let updatedAt: String?

    enum CodingKeys: String, CodingKey {
        case resource = "resource"
        case id = "id"
        case fixtureid = "fixture_id"
        case teamid = "team_id"
        case inning = "inning"
        case score = "score"
        case wickets = "wickets"
        case overs = "overs"
        case pp1 = "pp1"
        case pp2 = "pp2"
        case pp3 = "pp3"
        case updatedAt = "updated_at"
    }
}

enum Pp1: String, Codable {
    case the13 = "1-3"
    case the14 = "1-4"
    case the15 = "1-5"
    case the16 = "1-6"
}

enum RunResource: String, Codable {
    case runs = "runs"
}

enum Status: String, Codable {
    case finished = "Finished"
}

enum TypeEnum: String, Codable {
    case t20 = "T20"
    case t20I = "T20I"
}

// MARK: - Venue
struct Venue: Codable {
    let resource: VenueResource?
    let id: Int?
    let countryid: Int?
    let name: String?
    let city: String?
    let imagePath: String?
    let capacity: Int?
    let floodlight: Bool?
    let updatedAt: String?

    enum CodingKeys: String, CodingKey {
        case resource = "resource"
        case id = "id"
        case countryid = "country_id"
        case name = "name"
        case city = "city"
        case imagePath = "image_path"
        case capacity = "capacity"
        case floodlight = "floodlight"
        case updatedAt = "updated_at"
    }
}

enum VenueResource: String, Codable {
    case venues = "venues"
}

// MARK: - Links
struct Links: Codable {
    let first: String?
    let last: String?
    let prev: JSONNull?
    let next: String?

    enum CodingKeys: String, CodingKey {
        case first = "first"
        case last = "last"
        case prev = "prev"
        case next = "next"
    }
}

// MARK: - Meta
struct Meta: Codable {
    let currentPage: Int?
    let from: Int?
    let lastPage: Int?
    let links: [Link]?
    let path: String?
    let perPage: Int?
    let to: Int?
    let total: Int?

    enum CodingKeys: String, CodingKey {
        case currentPage = "current_page"
        case from = "from"
        case lastPage = "last_page"
        case links = "links"
        case path = "path"
        case perPage = "per_page"
        case to = "to"
        case total = "total"
    }
}

// MARK: - Link
struct Link: Codable {
    let url: String?
    let label: String?
    let active: Bool?

    enum CodingKeys: String, CodingKey {
        case url = "url"
        case label = "label"
        case active = "active"
    }
}

// MARK: - Encode/decode helpers

class JSONNull: Codable, Hashable {

    public static func == (lhs: JSONNull, rhs: JSONNull) -> Bool {
        return true
    }

    public var hashValue: Int {
        return 0
    }

    public init() {}

    public required init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if !container.decodeNil() {
            throw DecodingError.typeMismatch(JSONNull.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for JSONNull"))
        }
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encodeNil()
    }
}

class JSONCodingKey: CodingKey {
    let key: String

    required init?(intValue: Int) {
        return nil
    }

    required init?(stringValue: String) {
        key = stringValue
    }

    var intValue: Int? {
        return nil
    }

    var stringValue: String {
        return key
    }
}

class JSONAny: Codable {

    let value: Any

    static func decodingError(forCodingPath codingPath: [CodingKey]) -> DecodingError {
        let context = DecodingError.Context(codingPath: codingPath, debugDescription: "Cannot decode JSONAny")
        return DecodingError.typeMismatch(JSONAny.self, context)
    }

    static func encodingError(forValue value: Any, codingPath: [CodingKey]) -> EncodingError {
        let context = EncodingError.Context(codingPath: codingPath, debugDescription: "Cannot encode JSONAny")
        return EncodingError.invalidValue(value, context)
    }

    static func decode(from container: SingleValueDecodingContainer) throws -> Any {
        if let value = try? container.decode(Bool.self) {
            return value
        }
        if let value = try? container.decode(Int64.self) {
            return value
        }
        if let value = try? container.decode(Double.self) {
            return value
        }
        if let value = try? container.decode(String.self) {
            return value
        }
        if container.decodeNil() {
            return JSONNull()
        }
        throw decodingError(forCodingPath: container.codingPath)
    }

    static func decode(from container: inout UnkeyedDecodingContainer) throws -> Any {
        if let value = try? container.decode(Bool.self) {
            return value
        }
        if let value = try? container.decode(Int64.self) {
            return value
        }
        if let value = try? container.decode(Double.self) {
            return value
        }
        if let value = try? container.decode(String.self) {
            return value
        }
        if let value = try? container.decodeNil() {
            if value {
                return JSONNull()
            }
        }
        if var container = try? container.nestedUnkeyedContainer() {
            return try decodeArray(from: &container)
        }
        if var container = try? container.nestedContainer(keyedBy: JSONCodingKey.self) {
            return try decodeDictionary(from: &container)
        }
        throw decodingError(forCodingPath: container.codingPath)
    }

    static func decode(from container: inout KeyedDecodingContainer<JSONCodingKey>, forKey key: JSONCodingKey) throws -> Any {
        if let value = try? container.decode(Bool.self, forKey: key) {
            return value
        }
        if let value = try? container.decode(Int64.self, forKey: key) {
            return value
        }
        if let value = try? container.decode(Double.self, forKey: key) {
            return value
        }
        if let value = try? container.decode(String.self, forKey: key) {
            return value
        }
        if let value = try? container.decodeNil(forKey: key) {
            if value {
                return JSONNull()
            }
        }
        if var container = try? container.nestedUnkeyedContainer(forKey: key) {
            return try decodeArray(from: &container)
        }
        if var container = try? container.nestedContainer(keyedBy: JSONCodingKey.self, forKey: key) {
            return try decodeDictionary(from: &container)
        }
        throw decodingError(forCodingPath: container.codingPath)
    }

    static func decodeArray(from container: inout UnkeyedDecodingContainer) throws -> [Any] {
        var arr: [Any] = []
        while !container.isAtEnd {
            let value = try decode(from: &container)
            arr.append(value)
        }
        return arr
    }

    static func decodeDictionary(from container: inout KeyedDecodingContainer<JSONCodingKey>) throws -> [String: Any] {
        var dict = [String: Any]()
        for key in container.allKeys {
            let value = try decode(from: &container, forKey: key)
            dict[key.stringValue] = value
        }
        return dict
    }

    static func encode(to container: inout UnkeyedEncodingContainer, array: [Any]) throws {
        for value in array {
            if let value = value as? Bool {
                try container.encode(value)
            } else if let value = value as? Int64 {
                try container.encode(value)
            } else if let value = value as? Double {
                try container.encode(value)
            } else if let value = value as? String {
                try container.encode(value)
            } else if value is JSONNull {
                try container.encodeNil()
            } else if let value = value as? [Any] {
                var container = container.nestedUnkeyedContainer()
                try encode(to: &container, array: value)
            } else if let value = value as? [String: Any] {
                var container = container.nestedContainer(keyedBy: JSONCodingKey.self)
                try encode(to: &container, dictionary: value)
            } else {
                throw encodingError(forValue: value, codingPath: container.codingPath)
            }
        }
    }

    static func encode(to container: inout KeyedEncodingContainer<JSONCodingKey>, dictionary: [String: Any]) throws {
        for (key, value) in dictionary {
            let key = JSONCodingKey(stringValue: key)!
            if let value = value as? Bool {
                try container.encode(value, forKey: key)
            } else if let value = value as? Int64 {
                try container.encode(value, forKey: key)
            } else if let value = value as? Double {
                try container.encode(value, forKey: key)
            } else if let value = value as? String {
                try container.encode(value, forKey: key)
            } else if value is JSONNull {
                try container.encodeNil(forKey: key)
            } else if let value = value as? [Any] {
                var container = container.nestedUnkeyedContainer(forKey: key)
                try encode(to: &container, array: value)
            } else if let value = value as? [String: Any] {
                var container = container.nestedContainer(keyedBy: JSONCodingKey.self, forKey: key)
                try encode(to: &container, dictionary: value)
            } else {
                throw encodingError(forValue: value, codingPath: container.codingPath)
            }
        }
    }

    static func encode(to container: inout SingleValueEncodingContainer, value: Any) throws {
        if let value = value as? Bool {
            try container.encode(value)
        } else if let value = value as? Int64 {
            try container.encode(value)
        } else if let value = value as? Double {
            try container.encode(value)
        } else if let value = value as? String {
            try container.encode(value)
        } else if value is JSONNull {
            try container.encodeNil()
        } else {
            throw encodingError(forValue: value, codingPath: container.codingPath)
        }
    }

    public required init(from decoder: Decoder) throws {
        if var arrayContainer = try? decoder.unkeyedContainer() {
            self.value = try JSONAny.decodeArray(from: &arrayContainer)
        } else if var container = try? decoder.container(keyedBy: JSONCodingKey.self) {
            self.value = try JSONAny.decodeDictionary(from: &container)
        } else {
            let container = try decoder.singleValueContainer()
            self.value = try JSONAny.decode(from: container)
        }
    }

    public func encode(to encoder: Encoder) throws {
        if let arr = self.value as? [Any] {
            var container = encoder.unkeyedContainer()
            try JSONAny.encode(to: &container, array: arr)
        } else if let dict = self.value as? [String: Any] {
            var container = encoder.container(keyedBy: JSONCodingKey.self)
            try JSONAny.encode(to: &container, dictionary: dict)
        } else {
            var container = encoder.singleValueContainer()
            try JSONAny.encode(to: &container, value: self.value)
        }
    }
}
