//
//  MatchDetailsVC.swift
//  Cric_Tracker
//
//  Created by BJIT on 15/2/23.
//

import UIKit
import SDWebImage

class MatchDetailsVC: UIViewController {
   
    @IBOutlet weak var segmentControl: UISegmentedControl!
    
    @IBOutlet weak var dvBGView: UIView!
    @IBOutlet weak var firstView: UIView!
    @IBOutlet weak var secondView: UIView!
    var viewModel : ViewModel!
    @IBOutlet weak var visitorTeamName: UILabel!
    @IBOutlet weak var homeTeamName: UILabel!
    @IBOutlet weak var visitorTFlag: UIImageView!
    @IBOutlet weak var homeTFlag: UIImageView!
    @IBOutlet weak var thirdView: UIView!
    
    @IBOutlet weak var team1ScoreL: UILabel!
    @IBOutlet weak var team2ScoreL: UILabel!
    override func viewWillAppear(_ animated: Bool) {
        tabBarController?.tabBar.isHidden = true
    }
    override func viewWillDisappear(_ animated: Bool) {
        tabBarController?.tabBar.isHidden = false
    }
    
    var id: Int?

    var rcvData: MatchData?{
        didSet{
            
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toplayerInfo" {
            if let destinationVC = segue.destination as? MatchinfoVIewController {
                destinationVC.receivedData = rcvData
            }
        }
        else if segue.identifier == "toScoreBoard" {
            if let destinationVC1 = segue.destination as? ScoreBoardVC {
                destinationVC1.rcvData = rcvData
            }
        }
        else if segue.identifier == "toSquadVC" {
            if let destinationVC2 = segue.destination as? SquadVC {
                destinationVC2.rcvData1 = rcvData
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        firstView.alpha = 1
        secondView.alpha = 0
        thirdView.alpha = 0
        homeTeamName.text = rcvData?.localteam?.name
        visitorTeamName.text = rcvData?.visitorteam?.name
        let hometeamFlag = rcvData?.localteam?.imagePath
        if let image = hometeamFlag{
            homeTFlag.sd_setImage(with: URL(string: image))
        }
        let visitingteamFlag = rcvData?.visitorteam?.imagePath
        if let image1 = visitingteamFlag{
            visitorTFlag.sd_setImage(with: URL(string: image1))
        }
        let score1 = rcvData?.runs?[0].score ?? 0
        let wick1 = rcvData?.runs?[0].wickets ?? 0
        let ovr1 = rcvData?.runs?[0].overs ?? 0.0
        let score2 = rcvData?.runs?[1].score ?? 0
        let wick2 = rcvData?.runs?[1].wickets ?? 0
        let ovr2 = rcvData?.runs?[1].overs ?? 0.0
        team1ScoreL.text = "\(score1)/\(wick1) (\(ovr1))"
        team2ScoreL.text = "\(score2)/\(wick2) (\(ovr2))"
        
        
        
        dvBGView.round(28)
        homeTFlag.layer.cornerRadius = homeTFlag.frame.size.width / 2
        homeTFlag.clipsToBounds = true
        visitorTFlag.layer.cornerRadius = visitorTFlag.frame.size.width / 2
        homeTFlag.clipsToBounds = true
        
    }

    
    @IBAction func switchViews(_ sender: UISegmentedControl) {
        
        if sender.selectedSegmentIndex == 0{

            firstView.alpha = 1
            secondView.alpha = 0
            thirdView.alpha = 0
        }
        else if sender.selectedSegmentIndex == 1{
            firstView.alpha = 0
            secondView.alpha = 1
            thirdView.alpha = 0
        }
        else if sender.selectedSegmentIndex == 2{
            firstView.alpha = 0
            secondView.alpha = 0
            thirdView.alpha = 1
            
        }
    else{
        
    }
    }
    

    
}
