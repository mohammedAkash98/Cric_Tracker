//
//  MatchInfortableViewCellTableViewCell.swift
//  Cric_Tracker
//
//  Created by Akash on 18/2/23.
//

import UIKit

class MatchInfortableViewCellTableViewCell: UITableViewCell {

    
    @IBOutlet weak var pomImage: UIImageView!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var tournamentLabel: UILabel!
    
    @IBOutlet weak var pofName: UILabel!
    @IBOutlet weak var venueLabel: UILabel!
    
    @IBOutlet weak var tossLabel: UILabel!
    @IBOutlet weak var matchNoLabel: UILabel!
    @IBOutlet weak var stadiumImg: UIImageView!
    @IBOutlet weak var umpireLabel: UILabel!
    @IBOutlet weak var thirdUmpLabel: UILabel!
    @IBOutlet weak var refereeLabel: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
