//
//  MatchinfoVIewController.swift
//  Cric_Tracker
//
//  Created by BJIT on 16/2/23.
//

import UIKit

class MatchinfoVIewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 750
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "infoCell",for: indexPath) as! MatchInfortableViewCellTableViewCell
        cell.tournamentLabel.text = receivedData?.league?.name
        cell.pofName.text = receivedData?.manofmatch?.fullname
        let momImage = receivedData?.manofmatch?.imagePath
        if let newImage = momImage{
            cell.pomImage.sd_setImage(with: URL(string: newImage))
        }
        cell.matchNoLabel.text = receivedData?.round
        //cell.tossLabel.text = receivedData?.
        cell.venueLabel.text = receivedData?.venue?.name
        let venueImage = receivedData?.venue?.imagePath
        if let venueImg = venueImage{
            cell.stadiumImg.sd_setImage(with: URL(string: venueImg))
        }
        let dateString = receivedData?.startingAt
        let inputFormatter = ISO8601DateFormatter()
        inputFormatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        
        if let date = inputFormatter.date(from: dateString ?? "Date not found") {
            let outputFormatter = DateFormatter()
            outputFormatter.dateFormat = "yyyy-MM-dd HH:mm at"
            let outputString = outputFormatter.string(from: date)
            print(outputString) // Output: February 16, 2023
            cell.dateLabel.text = outputString
            
        
        } else {
            print("Invalid date string")
        }
        
        if let winTossTeamName = receivedData?.tosswon?.name, let electedT = receivedData?.elected?.rawValue {
            var tossR = "\(winTossTeamName) won the toss and elected to \(electedT) first"
            cell.tossLabel.text = tossR
        }
        
       
        
       
        return cell
    }
    
    
    @IBOutlet weak var infotableView: UITableView!
    var id: Int?
    var receivedData : MatchData?
    var rcvData: MatchData?{
        didSet{
            
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        infotableView.delegate = self
        infotableView.dataSource = self
        let nib1 = UINib(nibName: "MatchInfortableViewCellTableViewCell", bundle: nil)
        infotableView.register(nib1, forCellReuseIdentifier: "infoCell")
        //tournamentLabel.text = receivedData?.note

        // Do any additional setup after loading the view.
    }
    
}
