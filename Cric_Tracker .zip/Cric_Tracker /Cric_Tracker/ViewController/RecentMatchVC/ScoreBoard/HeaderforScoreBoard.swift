//
//  HeaderforScoreBoard.swift
//  Cric_Tracker
//
//  Created by BJIT on 20/2/23.
//

import UIKit

class HeaderforScoreBoard: UITableViewHeaderFooterView {

    @IBOutlet weak var labelOne: UILabel!
    
    @IBOutlet weak var hdView: UIView!
    @IBOutlet weak var scoreBoardBG: UIView!
    @IBOutlet weak var labelTwo: UILabel!
    
    @IBOutlet weak var labelThree: UILabel!
    
    @IBOutlet weak var labelFour: UILabel!
    
    @IBOutlet weak var labelFive: UILabel!
    
    func setupCell(labelOne: String, labelTwo: String, labeLThree: String, labelFour: String, labelFive: String){
        self.labelOne.text = labelOne
        self.labelTwo.text = labelTwo
        self.labelThree.text = labeLThree
        self.labelFour.text = labelFour
        self.labelFive.text = labelFive
        
    }
    override func awakeFromNib() {
            super.awakeFromNib()
        scoreBoardBG.layer.cornerRadius = 10
        }
   
}
