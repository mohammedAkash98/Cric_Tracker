//
//  ScoreBoardVC.swift
//  Cric_Tracker
//
//  Created by Akash on 18/2/23.
//

import UIKit
import SystemConfiguration

class ScoreBoardVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var bgScoreB: UIView!
    
    @IBOutlet weak var scoreBoardTable: UITableView!
     
     var receivedata1 : MatchData1?
     var id: Int?
     
     var rcvData: MatchData?{
         didSet{
             
         }
     }
    var battingTeam1: [Batting] = []{
        didSet{
            
        }
    }
    var battingTeam2: [Batting] = []{
        didSet{
            
        }
    }
    var bowlingTeam1: [Bowling] = []{
        didSet{
            
        }
    }
    var bowlingTeam2: [Bowling] = []{
        didSet{
            
        }
    }
 
     override func viewDidLoad() {
         super.viewDidLoad()
         if !NetCh.shared.isInternetAvailable() {
             let alert = UIAlertController(title: "No Internet Connection",
                                           message: "Please check your internet connection and try again.",
                                           preferredStyle: .alert)
             alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
             self.present(alert, animated: true, completion: nil)
             
             // Do any additional setup after loading the view.
         }
         //bgScoreB?.layer.cornerRadius = 20
         if let tempBowlTeam = self.rcvData?.bowling{
             for data in tempBowlTeam{
                 if self.rcvData?.localteamid == data.teamid{
                     self.bowlingTeam1.append(data)
                 }
                 else{
                     self.bowlingTeam2.append(data)
                 }
             }
         }
         if let tempBatTeam = self.rcvData?.batting{
             for data in tempBatTeam{
                 if self.rcvData?.localteamid == data.teamid{
                     self.battingTeam1.append(data)
                 }
                 else{
                     self.battingTeam2.append(data)
                 }
             }
             print("team 1:", battingTeam1)
             print("team 2:", battingTeam2)
         }

         
         
         scoreBoardTable.delegate = self
         scoreBoardTable.dataSource = self

         let Scorenib = UINib(nibName: "ScoreBoardCell", bundle: nil)
         scoreBoardTable.register(Scorenib, forCellReuseIdentifier: "battingCell")
         let nibHeader = UINib(nibName: "HeaderforScoreBoard", bundle: nil)
         scoreBoardTable.register(nibHeader, forHeaderFooterViewReuseIdentifier: "HeaderforScoreBoard")
     }
   
        
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0{
            
           return battingTeam1.count ?? 11
        }
        else if section == 1{
            return bowlingTeam2.count ?? 11
        }
        else if section == 2{
            return battingTeam2.count ?? 11
        }
        else if section == 3{
            
            return bowlingTeam1.count ?? 11
            

        }
        else{
            return 11
        }
        
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = scoreBoardTable.dequeueReusableHeaderFooterView(withIdentifier: "HeaderforScoreBoard") as! HeaderforScoreBoard
        var sfa = rcvData?.runs?[0].inning ?? 0
        var tfa = rcvData?.runs?[1].inning ?? 0
        if section == 0{
            header.setupCell(labelOne: "Innings-\(String(describing: sfa)) Batter", labelTwo: "R", labeLThree: "B", labelFour: "4", labelFive: "6")

            
        }
        else if section == 1{
            header.setupCell(labelOne: "Innings-\(String(describing: sfa)) Bowler", labelTwo: "O", labeLThree: "M", labelFour: "R", labelFive: "W")
        }
        else if section == 2{
            header.setupCell(labelOne: "Innings-\(String(describing: tfa)) Batter", labelTwo: "R", labeLThree: "B", labelFour: "4", labelFive: "6")
            
        }
        else if section == 3{
            header.setupCell(labelOne: "Innings-\(String(describing: tfa)) Bowler", labelTwo: "O", labeLThree: "M", labelFour: "R", labelFive: "W")
            
        }
                
        return header
    }
   
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
            
            let cell = scoreBoardTable.dequeueReusableCell(withIdentifier: "battingCell",for: indexPath) as! ScoreBoardCell
        if indexPath.section == 0{
            let score = battingTeam1[indexPath.row].score ?? 0
            cell.runLabel.text = "\((score))"
            let ball = battingTeam1[indexPath.row].ball ?? 0
            cell.ballLabel.text = "\((ball))"
            cell.batsmenLabel.text = battingTeam1[indexPath.row].batsman?.fullname
            let four = battingTeam1[indexPath.row].fourX ?? 0
            cell.fourLabel.text = "\((four))"
            let six = battingTeam1[indexPath.row].sixX ?? 0
            cell.sixLabel.text = "\((six))"
            //let out = battingTeam1[indexPath.row].s
            
        }
        else if indexPath.section == 1{
            let overs = bowlingTeam2[indexPath.row].overs ?? 0.0
            cell.runLabel.text = "\((overs))"
            let medians = bowlingTeam2[indexPath.row].medians ?? 0
            cell.ballLabel.text = "\((medians))"
            cell.batsmenLabel.text = bowlingTeam2[indexPath.row].bowler?.fullname
            let runsConceded = bowlingTeam2[indexPath.row].runs ?? 0
            cell.fourLabel.text = "\((runsConceded))"
            let wickets = bowlingTeam2[indexPath.row].wickets ?? 0
            cell.sixLabel.text = "\((wickets))"
            
            
            
        }
        else if indexPath.section == 2{
            let score = battingTeam2[indexPath.row].score ?? 0
            cell.runLabel.text = "\((score))"
            let ball = battingTeam2[indexPath.row].ball ?? 0
            cell.ballLabel.text = "\((ball))"
            cell.batsmenLabel.text = battingTeam2[indexPath.row].batsman?.fullname
            let four = battingTeam2[indexPath.row].fourX ?? 0
            cell.fourLabel.text = "\((four))"
            let six = battingTeam2[indexPath.row].sixX ?? 0
            cell.sixLabel.text = "\((six))"
            
            
        }
        else if indexPath.section == 3{
            
            let overs = bowlingTeam1[indexPath.row].overs ?? 0.0
            cell.runLabel.text = "\((overs))"
            let medians = bowlingTeam1[indexPath.row].medians ?? 0
            cell.ballLabel.text = "\((medians))"
            cell.batsmenLabel.text = bowlingTeam1[indexPath.row].bowler?.fullname
            let runsConceded = bowlingTeam1[indexPath.row].runs ?? 0
            cell.fourLabel.text = "\((runsConceded))"
            let wickets = bowlingTeam1[indexPath.row].wickets ?? 0
            cell.sixLabel.text = "\((wickets))"
        }
        else{
        
        }
            
            //cell.outLabel.text = rcvData?.batting![indexPath.row].
            
            //recentMatch.data![0].batting![0].score
            return cell
        
       
    }
    

   

}
