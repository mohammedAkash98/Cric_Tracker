//
//  ScoreBoardCell.swift
//  Cric_Tracker
//
//  Created by BJIT on 20/2/23.
//

import UIKit

class ScoreBoardCell: UITableViewCell {

    @IBOutlet weak var runLabel: UILabel!
    
    @IBOutlet weak var batsmenLabel: UILabel!
    
    @IBOutlet weak var ballLabel: UILabel!
    
    @IBOutlet weak var fourLabel: UILabel!
    
    @IBOutlet weak var sixLabel: UILabel!
    
    @IBOutlet weak var outLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
