//
//  SquadHeader.swift
//  Cric_Tracker
//
//  Created by BJIT on 25/2/23.
//

import UIKit

class SquadHeader: UITableViewHeaderFooterView {

    @IBOutlet weak var teamNAmeS: UILabel!
    
    @IBOutlet weak var HeadBG: UIView!
    func setupHead(teamNAmeS: String){
        self.teamNAmeS.text = teamNAmeS
    }
    override func awakeFromNib() {
            super.awakeFromNib()
        HeadBG.layer.cornerRadius = 10
        }
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
