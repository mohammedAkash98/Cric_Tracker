//
//  SquadVC.swift
//  Cric_Tracker
//
//  Created by BJIT on 21/2/23.
//

import UIKit
import SDWebImage

class SquadVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
   
    @IBOutlet weak var squadtableView: UITableView!
    var rcvData1: MatchData?{
        didSet{
            
        
            
        }
    }
    
    var lineupTeam1: [LineupElement] = []{
        
        didSet{
            DispatchQueue.main.async {
                self.squadtableView.reloadData()
            }
            
        }
    }
    var lineupTeam2: [LineupElement] = [] {
        
        didSet{
            DispatchQueue.main.async {
                self.squadtableView.reloadData()
            }
            
        }
    }
        

    var viewmodel = ViewModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        if let tempLineup = self.rcvData1?.lineup {

            for data in tempLineup{

                if self.rcvData1?.localteamid == data.lineup?.teamid{
                    self.lineupTeam1.append(data)
                }
                else {
                    self.lineupTeam2.append(data)
                }

            }
            
            print("team 1:", lineupTeam1)
            print("team 2:", lineupTeam2)
            
//
        }
        
//
        
        //viewmodel.getSquadFromApi()
        viewmodel.squadData.bind{
            data in
            print("squad data:",data)
            
            
            DispatchQueue.main.async {
                self.squadtableView.reloadData()
            }
        }
        let squadNib1 = UINib(nibName: "SquadHeader", bundle: nil)
        squadtableView.register(squadNib1, forHeaderFooterViewReuseIdentifier: "SquadHeader")
        squadtableView.delegate = self
        squadtableView.dataSource = self
        let squadNib = UINib(nibName: "SquadTableViewCell", bundle: nil)
        squadtableView.register(squadNib, forCellReuseIdentifier: "playerNameCell")

        // Do any additional setup after loading the view.
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return rcvData1?.lineup?.count ?? 11
        
        if section == 0{
            
           return lineupTeam1.count
        }
        else
        {
            return lineupTeam2.count

        }
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header1 = squadtableView.dequeueReusableHeaderFooterView(withIdentifier: "SquadHeader") as! SquadHeader
        var firstT = rcvData1?.localteam?.name ?? "no"
        var secondT = rcvData1?.visitorteam?.name ?? " yes"
            if section == 0{
                header1.setupHead(teamNAmeS: "\(firstT)")
            
        }
        else if section == 1{
            header1.setupHead(teamNAmeS: "\(secondT)")
            
        }
        else{
            
        }
        return header1
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        var lineUp: [LineupInfo] = []
        
        
        let cell = squadtableView.dequeueReusableCell(withIdentifier: "playerNameCell",for: indexPath) as! SquadTableViewCell
        if indexPath.section == 0{
            
            cell.playerNameLabel.text = lineupTeam1[indexPath.row].fullname
            let playerImage = lineupTeam1[indexPath.row].imagePath
            
            if let image1 = playerImage{
                cell.playerImg.sd_setImage(with: URL(string: image1))
            }
          

            
        }
       
        else {
            
            cell.playerNameLabel.text = lineupTeam2[indexPath.row].fullname
            let playerImage1 = lineupTeam2[indexPath.row].imagePath
            
            if let image = playerImage1{
                cell.playerImg.sd_setImage(with: URL(string: image))
            }

        }
        return cell
        
    }
   


}
