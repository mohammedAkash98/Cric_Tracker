//
//  UpcomingMatchVC.swift
//  Cric_Tracker
//
//  Created by BJIT on 17/2/23.
//

import UIKit

class UpcomingMatchVC: UIViewController {
    
    @IBOutlet weak var localteamName: UILabel!
    var viewModel = ViewModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        setupBinder()
        
        // Do any additional setup after loading the view.
    }
  

    
    func setupBinder(){
        viewModel.upcomingMatchDataById.bind{ [weak self] data in
            print("upcoming data:",data)
            DispatchQueue.main.async {
                self?.localteamName.text = self?.viewModel.upcomingMatchDataById.value?.data?.localteam?.name
            }
            
            
            /*
             // MARK: - Navigation
             
             // In a storyboard-based application, you will often want to do a little preparation before navigation
             override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
             // Get the new view controller using segue.destination.
             // Pass the selected object to the new view controller.
             }
             */
            
        }
    }
}
