//
//  ViewController+CollectionView.swift
//  Cric_Tracker
//
//  Created by BJIT on 10/2/23.
//

import Foundation
import UIKit
import SDWebImage

extension ViewController: UICollectionViewDelegate,UICollectionViewDataSource{
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.matchData.value?.data?.count ?? 20
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        if scrollView.contentOffset.y > 0 {
            
            UIView.animate(withDuration: 0.3) { [weak self] in
//                self?.collectionView.alpha = 1
//                self?.collectionView.alpha = 0
                self?.collectionView.isHidden = true
                self?.collectioTopCons.constant = 400
                self?.collectioTopCons.constant = 0
                self?.consLogoV.constant = 170
                
            
                self?.upcomingLabel.textColor = UIColor.black
                self?.upcomingLabel.textColor = UIColor.white
                self?.up1Bg.isHidden = true
                self?.view.layoutIfNeeded()
                
            }
        }
        else {
            UIView.animate(withDuration: 0.6) { [weak self] in
//                self?.collectionView.alpha = 0
//                self?.collectionView.alpha = 1
                self?.collectionView.isHidden = false
                self?.collectioTopCons.constant = 0
                self?.collectioTopCons.constant = 300
                self?.consLogoV.constant = 235
                
                self?.upcomingLabel.textColor = UIColor.white
                self?.upcomingLabel.textColor = UIColor.black
                self?.up1Bg.isHidden = false
                self?.view.layoutIfNeeded()
            }
        }
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        1
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        performSegue(withIdentifier: "toDetailVC", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //let indexPath = sender as! IndexPath
        let indexX = collectionView.indexPathsForSelectedItems
        if segue.identifier == "toDetailVC" {
            if let destinationVC = segue.destination as? MatchDetailsVC{
                destinationVC.rcvData = viewModel.matchData.value?.data?[indexX?[0].row ?? 0]
                
            }
            
        }
//        
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionVNIB", for: indexPath) as! CollectionViewCell1
        cell.homeTName.text = viewModel.matchData.value?.data?[indexPath.row].localteam?.code
        cell.visitorTName.text = viewModel.matchData.value?.data?[indexPath.row].visitorteam?.code
        
        let hometeamFlag = viewModel.matchData.value?.data?[indexPath.row].localteam?.imagePath
        if let img = hometeamFlag{
            cell.homeTFlag.sd_setImage(with: URL(string: img))
        }
        let visitorteamFlag = viewModel.matchData.value?.data?[indexPath.row].visitorteam?.imagePath
        if let img1 = visitorteamFlag{
            cell.visitorTFlag.sd_setImage(with: URL(string: img1))
        }
        cell.matchResult.text = viewModel.matchData.value?.data?[indexPath.row].note
        
        if (viewModel.matchData.value?.data?[indexPath.row].localteamid == viewModel.matchData.value?.data?[indexPath.row].runs?[0].teamid) {
            let score = viewModel.matchData.value?.data?[indexPath.row].runs?[0].score
            let wicket = viewModel.matchData.value?.data?[indexPath.row].runs?[0].wickets
            let overs = viewModel.matchData.value?.data?[indexPath.row].runs?[0].overs
            cell.homeTScore.text = "\(score ?? 0)/\(wicket ?? 0)(\(overs ?? 0))"
            let score1 = viewModel.matchData.value?.data?[indexPath.row].runs?[1].score
            let wicket1 = viewModel.matchData.value?.data?[indexPath.row].runs?[1].wickets
            let overs1 = viewModel.matchData.value?.data?[indexPath.row].runs?[1].overs
            cell.visitorTScore.text = "\(score1 ?? 0)/\(wicket1 ?? 0)(\(overs1 ?? 0))"
            
        }
        else if (viewModel.matchData.value?.data?[indexPath.row].localteamid == viewModel.matchData.value?.data?[indexPath.row].runs?[1].teamid){
            let score = viewModel.matchData.value?.data?[indexPath.row].runs?[1].score
            let wicket = viewModel.matchData.value?.data?[indexPath.row].runs?[1].wickets
            let overs = viewModel.matchData.value?.data?[indexPath.row].runs?[1].overs
            cell.homeTScore.text = "\(score ?? 0)/\(wicket ?? 0)(\(overs ?? 0))"
            let score1 = viewModel.matchData.value?.data?[indexPath.row].runs?[0].score
            let wicket1 = viewModel.matchData.value?.data?[indexPath.row].runs?[0].wickets
            let overs1 = viewModel.matchData.value?.data?[indexPath.row].runs?[0].overs
            cell.visitorTScore.text = "\(score1 ?? 0)/\(wicket1 ?? 0)(\(overs1 ?? 0))"
            
        }
        
        cell.venueLabel.text = viewModel.matchData.value?.data?[indexPath.row].venue?.name
        cell.matchNLabel.text = "\(viewModel.matchData.value?.data?[indexPath.row].league?.name ?? "null"),\(viewModel.matchData.value?.data?[indexPath.row].round ?? "null")"
        cell.momName.text = viewModel.matchData.value?.data?[indexPath.row].manofmatch?.fullname
        let manofMatch = viewModel.matchData.value?.data?[indexPath.row].manofmatch?.imagePath
        if let img3 = manofMatch{
            cell.momImg.sd_setImage(with: URL(string: img3))
        }
        //cell.momType.text = viewModel.matchData.value?.data?[indexPath.row].run
        
        return cell
    }
}
