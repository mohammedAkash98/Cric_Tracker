//
//  ViewController+tableView.swift
//  Cric_Tracker
//
//  Created by BJIT on 14/2/23.
//

import Foundation
import UIKit
import SDWebImage
extension ViewController: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 15
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 140
    }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tableXIB",for: indexPath) as! TableViewCell
        cell.homeTNaemL.text = viewModel.upcomingMatchData.value?.data[indexPath.row].localteam?.code
        cell.visitorTNameL.text = viewModel.upcomingMatchData.value?.data[indexPath.row].visitorteam?.code
        cell.venueNameL.text = viewModel.upcomingMatchData.value?.data[indexPath.row].venue?.name
        let homeTmFlag = viewModel.upcomingMatchData.value?.data[indexPath.row].localteam?.imagePath
        if let image = homeTmFlag{
            cell.homeTImg.sd_setImage(with: URL(string: image))
        }
        let visitorTmFlag = viewModel.upcomingMatchData.value?.data[indexPath.row].visitorteam?.imagePath
        
        if let image1 = visitorTmFlag{
            cell.visitorTImg.sd_setImage(with: URL(string: image1))
        }
        print(viewModel.upcomingMatchData.value?.data[indexPath.row].starting_at ?? "no data")
//
        let dateString = viewModel.upcomingMatchData.value?.data[indexPath.row].starting_at
        let inputFormatter = ISO8601DateFormatter()
        inputFormatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]

        if let date = inputFormatter.date(from: dateString ?? "Date not found") {
            let outputFormatter = DateFormatter()
            outputFormatter.dateFormat = "yyyy-MM-dd HH:mm at"
            let outputString = outputFormatter.string(from: date)
            print(outputString) // Output: February 16, 2023
            cell.dateLabel.text = outputString
        } else {
            print("Invalid date string")
        }
       
        
        
        return cell
    }
    
    
}
