//
//  tableViewCellTableViewCell.swift
//  Cric_Tracker
//
//  Created by BJIT on 14/2/23.
//

import UIKit

class TableViewCell: UITableViewCell {
    
    @IBOutlet weak var visitorTImg: UIImageView!
    @IBOutlet weak var homeTImg: UIImageView!
    
    
    @IBOutlet weak var homeTNaemL: UILabel!
    
    
    @IBOutlet weak var tableViewBG: UIView!
    @IBOutlet weak var visitorTNameL: UILabel!
    
    @IBOutlet weak var dateLabel: UILabel!
    
    @IBOutlet weak var venueNameL: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        tableViewBG.round(20)
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
