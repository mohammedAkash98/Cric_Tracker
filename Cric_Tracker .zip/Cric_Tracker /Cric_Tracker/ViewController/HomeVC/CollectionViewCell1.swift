//
//  CollectionViewCell1.swift
//  Cric_Tracker
//
//  Created by BJIT on 13/2/23.
//

import UIKit

class CollectionViewCell1: UICollectionViewCell {
    
    @IBOutlet weak var matchNLabel: UILabel!
    @IBOutlet weak var homeTFlag: UIImageView!
    
    @IBOutlet weak var collectionBG: UIView!
    @IBOutlet weak var visitorTFlag: UIImageView!
    
    @IBOutlet weak var homeTName: UILabel!
    
    
    @IBOutlet weak var visitorTName: UILabel!
    
    @IBOutlet weak var momType: UILabel!
    @IBOutlet weak var momName: UILabel!
    @IBOutlet weak var momImg: UIImageView!
    @IBOutlet weak var venueLabel: UILabel!
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var homeTScore: UILabel!
    
    @IBOutlet weak var momBG: UIView!
    @IBOutlet weak var scoreBG: UIView!
    @IBOutlet weak var visitorTScore: UILabel!
    
    @IBOutlet weak var matchResult: UITextField!
    var scoreToDisplay : RecentMatch?
    func scoreDisplay(_ score : RecentMatch){
        scoreToDisplay = score
        
        //homeTName.text = scoreToDisplay.
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        flagSize()
        
    }
    
    func flagSize(){
        //        collectionBG.round(15)
        scoreBG.round(10)
        momBG.round(10)
        bgView.round(20)
        visitorTFlag.layer.cornerRadius = 10
        visitorTFlag.layer.masksToBounds = true
        homeTFlag.layer.cornerRadius = 10
        homeTFlag.layer.masksToBounds = true
        bgView.round(10)
        
    }
    
}
