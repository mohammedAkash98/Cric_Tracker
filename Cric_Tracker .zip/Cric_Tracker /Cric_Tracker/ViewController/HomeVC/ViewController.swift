//
//  ViewController.swift
//  Cric_Tracker
//
//  Created by BJIT on 10/2/23.
//

import UIKit
import SystemConfiguration

class ViewController: UIViewController {
    
    
    
    
    @IBOutlet weak var consPicwidt: NSLayoutConstraint!
    
    @IBOutlet weak var conslogPICt: NSLayoutConstraint!
    @IBOutlet weak var consLogoV: NSLayoutConstraint!
    @IBOutlet weak var upBG: UIView!
    @IBOutlet weak var up1Bg: UIView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var upcomingLabel: UILabel!
    @IBOutlet weak var collectioTopCons: NSLayoutConstraint!
   
    let viewModel = ViewModel()
    var timer: Timer?
    var matchStartTime: Date!
    override func viewDidLoad() {
         
        super.viewDidLoad()
        upBG.round(20)
        up1Bg.round(25)
        
        
        collectionView.round(20)
        scheduleNotification(title: "Southern Cursade vs Gozo Zalmi", body: "Starts in 5 minutes", timeInterval: 10)
        
        let nib = UINib(nibName: "CollectionViewCell1", bundle: nil)
        collectionView.register(nib, forCellWithReuseIdentifier:  "collectionVNIB")
        let nib1 = UINib(nibName: "tableViewCell", bundle: nil)
        tableView.register(nib1, forCellReuseIdentifier: "tableXIB")
        collectionView.delegate = self
        collectionView.dataSource = self
        let collectionViewCellLayout = UICollectionViewFlowLayout()
        collectionViewCellLayout.itemSize = CGSize(width: collectionView.frame.width + 10, height: collectionView.frame.height)
        collectionViewCellLayout.scrollDirection = .horizontal
        collectionView.collectionViewLayout = collectionViewCellLayout
        tableView.delegate = self
        tableView.dataSource = self
        viewModel.getDataFromApi()
        viewModel.getUpcomingDataFromApi()
        if !NetCh.shared.isInternetAvailable() {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let errorViewController = storyboard.instantiateViewController(withIdentifier:  "ErrorViewController")
            sleep(2)
//
                self.present(errorViewController, animated: true, completion: nil)

        }
        //NetCh.shared.checkInternetConnectivity()
        DispatchQueue.main.async {
            self.collectionView.reloadData()
        }
        viewModel.matchData.bind{ [weak self] data in
            //print("dump", data! )
            DispatchQueue.main.async {
                self?.collectionView.reloadData()
            }
            
        }
    }
    func scheduleNotification(title: String, body: String, timeInterval: TimeInterval) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: timeInterval, repeats: false)
        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request) { (error) in
            if let error = error {
                print("Error scheduling notification: \(error.localizedDescription)")
            } else {
                print("Notification scheduled successfully")
            }
        }
    }
    
    
    
}








