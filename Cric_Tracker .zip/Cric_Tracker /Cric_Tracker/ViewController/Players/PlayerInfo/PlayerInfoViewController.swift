//
//  PlayerInfoViewController.swift
//  Cric_Tracker
//
//  Created by BJIT on 24/2/23.
//

import UIKit
import Combine
import SDWebImage
import SystemConfiguration



class PlayerInfoViewController: UIViewController {
    @IBOutlet weak var playerSName: UILabel!
    @IBOutlet weak var countryLabel: UILabel!
    
    @IBOutlet weak var playerImages: UIImageView!
    
    @IBOutlet weak var navPlayerName: UILabel!
    
    @IBOutlet weak var bowlingLabel: UILabel!
    @IBOutlet weak var battingLabel: UILabel!
    
    @IBOutlet weak var navBar2: UINavigationItem!
    @IBOutlet weak var dateofBirthLabel: UILabel!
    
    var viewModel = ViewModel()
    private var cancellables: Set<AnyCancellable> = []
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpBinder()
        navBar2.backBarButtonItem?.tintColor = UIColor.white
        
        if !NetCh.shared.isInternetAvailable() {
                let alert = UIAlertController(title: "No Internet Connection",
                                              message: "Please check your internet connection and restart CricTracker.",
                                              preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        
    }


    func setUpBinder() {
        viewModel.careerPlayers.bind{ [weak self] data in
            //print("player data from career:",data)
            DispatchQueue.main.async {
                self?.navPlayerName.text = self?.viewModel.careerPlayers.value?.data?.fullname
                self?.playerSName.text = self?.viewModel.careerPlayers.value?.data?.fullname
                self?.countryLabel.text = self?.viewModel.careerPlayers.value?.data?.gender
                let playerPic = self?.viewModel.careerPlayers.value?.data?.image_path
                if let image = playerPic{
                    self?.playerImages.sd_setImage(with: URL(string: image))
                
                }
                self?.battingLabel.text = self?.viewModel.careerPlayers.value?.data?.battingstyle
                self?.bowlingLabel.text = self?.viewModel.careerPlayers.value?.data?.bowlingstyle
                self?.dateofBirthLabel.text = self?.viewModel.careerPlayers.value?.data?.dateofbirth
            }
        }
        
    }
   
    
}
