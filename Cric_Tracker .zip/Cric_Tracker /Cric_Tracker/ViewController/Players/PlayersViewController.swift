//
//  PlayersViewController.swift
//  Cric_Tracker
//
//  Created by BJIT on 23/2/23.
//

import UIKit
import SDWebImage
import CoreData

class PlayersViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return playerL?.count ?? 0
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 66
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        performSegue(withIdentifier: "toPlayerdetailsinfo", sender: indexPath)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = playertableView.dequeueReusableCell(withIdentifier: "playerCell", for: indexPath) as! PlayersTableViewCell
        //let playerStored = PlayerCoreData(context: context)
        cell.playerName.text = playerL?[indexPath.row].fullName
        let playerDP = playerL?[indexPath.row].image
        if let image1 = playerDP{
            cell.playerImage.sd_setImage(with: URL(string: image1))
        }
        
        
        return cell
    }
    
    
    @IBOutlet weak var PltopView: UIView!
    @IBOutlet weak var consHSc: NSLayoutConstraint!
    
    @IBOutlet weak var fYPLabel: UILabel!
    @IBOutlet weak var consTrailSrc: NSLayoutConstraint!
    @IBOutlet weak var consLeadSrc: NSLayoutConstraint!
    @IBOutlet weak var searchBar: UITextField!
    @IBOutlet weak var playertableView: UITableView!
    var viewModel = ViewModel()
    var playerL : [PlayerCoreData]?  = []
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.delegate = self
        PltopView.round(20)
        
        //SearchBar.shared.createSearchBar(searchBar: searchBar)
        
        
        playertableView.delegate = self
        playertableView.dataSource = self
        //viewModel.getPlayersFromApi()
        DispatchQueue.main.async {
            self.playertableView.reloadData()
        }
        viewModel.playerData.bind{ [weak self] data in
            print("playerdump", data!)
        }
        let playerNib = UINib(nibName: "PlayersTableViewCell", bundle: nil)
        playertableView.register(playerNib, forCellReuseIdentifier: "playerCell")
        
        
        
        playerL = CoreDataManager.shared.getPlayersBySearch(search: " ")
        // print(playerL?[0].fullName)
        print(playerL?.count ?? 0)
        playertableView.reloadData()
        
    }
 

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let indexPath = sender as! IndexPath
        if segue.identifier == "toPlayerdetailsinfo" {
            if let destinationVC = segue.destination as? PlayerInfoViewController {
                destinationVC.viewModel.getPlayersCareerFromApi(id: Int(playerL?[indexPath.row].id ?? 0))
                
            }
        }
    }

}
