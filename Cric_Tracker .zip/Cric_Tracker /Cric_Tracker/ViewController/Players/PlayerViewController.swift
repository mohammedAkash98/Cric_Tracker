
import Foundation
import UIKit


// MARK: - Uitext field delegate
extension PlayersViewController: UITextFieldDelegate{
    
    func setupTextField(){
        
        searchBar.round(5)
        //searchBar.addShadow(opecity: 0.8, size: 5, radius: 2, color: UIColor.darkGray)
        searchBar.addBorder(color: UIColor.systemGray6, width: 1)
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.transform = CGAffineTransform(scaleX: 0.01, y: 0.01)
        UIView.animate(withDuration: 0.9, delay: 0, usingSpringWithDamping: 0.6, initialSpringVelocity: 0.1, options: [], animations: {
            textField.transform = .identity
            textField.alpha = 1
        }, completion: nil)
        consHSc.constant = 45
    }

    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
        UIView.animate(withDuration: 0.25, delay: 0, usingSpringWithDamping: 0.6, initialSpringVelocity: 0.1, options: [], animations: {
            textField.transform = .identity
            textField.alpha = 1
        }, completion: nil)
        consHSc.constant = 0
    }
    
   
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let text = (searchBar.text! as NSString).replacingCharacters(in: range, with: string)
        if text != ""{
            self.playerL = CoreDataManager.shared.getPlayersBySearch(search: text)
            playertableView.reloadData()
        }
        return true
    }
}
