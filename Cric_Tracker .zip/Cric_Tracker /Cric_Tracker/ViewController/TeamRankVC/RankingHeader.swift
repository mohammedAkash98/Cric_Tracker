//
//  RankingHeader.swift
//  Cric_Tracker
//
//  Created by BJIT on 25/2/23.
//

import UIKit

class RankingHeader: UITableViewHeaderFooterView {

    @IBOutlet weak var SeriesType: UILabel!
    
    @IBOutlet weak var RankFView: UIView!
    @IBOutlet weak var teamName: UILabel!
   
    @IBOutlet weak var ratingLabel: UILabel!
    
    @IBOutlet weak var pointsLabel: UILabel!
    func setupRankingCell(SeriesType: String, teamName: String, ratingLabel: String, pointsLabel: String){
        self.SeriesType.text = SeriesType
        self.teamName.text = teamName
        self.pointsLabel.text = pointsLabel
        self.ratingLabel.text = ratingLabel
        
    }
    override func awakeFromNib() {
            super.awakeFromNib()
        RankFView.layer.cornerRadius = 10
        }
//    static func newVIEW(){
//        RankFView.layer.cornerRadius = 30
//    }
}

