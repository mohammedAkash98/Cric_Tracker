//
//  RankingTableViewCell.swift
//  Cric_Tracker
//
//  Created by BJIT on 21/2/23.
//

import UIKit

class RankingTableViewCell: UITableViewCell {

    @IBOutlet weak var rankLabel: UILabel!
    
    @IBOutlet weak var teamnameLabel: UILabel!
    
    @IBOutlet weak var totalPoints: UILabel!
    @IBOutlet weak var totalratingLabel: UILabel!
    
    @IBOutlet weak var teamImage2: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
