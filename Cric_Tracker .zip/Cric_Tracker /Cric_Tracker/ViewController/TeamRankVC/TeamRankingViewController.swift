//
//  TeamRankingViewController.swift
//  Cric_Tracker
//
//  Created by BJIT on 17/2/23.
//

import UIKit
import SDWebImage
import SystemConfiguration

class TeamRankingViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewmodel.rankingData.value?.data?[0].team?.count ?? 0
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = rankingTable.dequeueReusableHeaderFooterView(withIdentifier: "RankingHeader") as! RankingHeader
        if section == 0{
            header.setupRankingCell(SeriesType: "ICC Men Test Ranking", teamName: "No            Team", ratingLabel: "Rating", pointsLabel: "Total Points")
            
            
        }
        else if section == 1{
            header.setupRankingCell(SeriesType: "ICC Men ODI Ranking", teamName: "No            Team", ratingLabel: "Rating", pointsLabel: "Total Points")
        }
        else if section == 2{
            header.setupRankingCell(SeriesType: "ICC Men T20 Ranking", teamName: "No            Team", ratingLabel: "Rating", pointsLabel: "Total Points")
        }
        else{
            
        }
        return header
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "rankingCell", for: indexPath) as! RankingTableViewCell
        if indexPath.section == 0{
            cell.teamnameLabel.text = viewmodel.rankingData.value?.data?[0].team?[indexPath.row].name
            let playersImg = viewmodel.rankingData.value?.data?[0].team?[indexPath.row].imagePath
            
            if let image1 = playersImg{
                cell.teamImage2.sd_setImage(with: URL(string: image1))
            }
            
            let position = viewmodel.rankingData.value?.data?[0].team?[indexPath.row].position
            cell.rankLabel.text = "\((position)!)"
            let points = viewmodel.rankingData.value?.data?[0].team?[indexPath.row].ranking?.points
            cell.totalPoints.text = "\((points)!)"
            let ratings = viewmodel.rankingData.value?.data?[0].team?[indexPath.row].ranking?.rating
            cell.totalratingLabel.text = "\((ratings)!)"
        }
        else if indexPath.section == 1{
            cell.teamnameLabel.text = viewmodel.rankingData.value?.data?[1].team?[indexPath.row].name
            let playersImg = viewmodel.rankingData.value?.data?[1].team?[indexPath.row].imagePath
            
            if let image1 = playersImg{
                cell.teamImage2.sd_setImage(with: URL(string: image1))
            }
            let position = viewmodel.rankingData.value?.data?[1].team?[indexPath.row].position
            cell.rankLabel.text = "\((position)!)"
            let points = viewmodel.rankingData.value?.data?[1].team?[indexPath.row].ranking?.points
            cell.totalPoints.text = "\((points)!)"
            let ratings = viewmodel.rankingData.value?.data?[1].team?[indexPath.row].ranking?.rating
            cell.totalratingLabel.text = "\((ratings)!)"
        }
        else if indexPath.section == 2 {
            cell.teamnameLabel.text = viewmodel.rankingData.value?.data?[2].team?[indexPath.row].name
            let position = viewmodel.rankingData.value?.data?[2].team?[indexPath.row].position
            cell.rankLabel.text = "\((position)!)"
            let points = viewmodel.rankingData.value?.data?[2].team?[indexPath.row].ranking?.points
            cell.totalPoints.text = "\((points)!)"
            let ratings = viewmodel.rankingData.value?.data?[2].team?[indexPath.row].ranking?.rating
            cell.totalratingLabel.text = "\((ratings)!)"
        }
        else{
            
        }
        return cell
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        if scrollView.contentOffset.y > 0 {
            
            UIView.animate(withDuration: 0.3) { [weak self] in
                //                self?.collectionView.alpha = 1
                //                self?.collectionView.alpha = 0
                
                
                
                self?.consTableView.constant = 682
                self?.topVieW.round(0)
                self?.consUpView.constant = 100
                self?.view.layoutIfNeeded()
                
            }
        }
        else {
            UIView.animate(withDuration: 0.6) { [weak self] in
                //                self?.collectionView.alpha = 0
                //                self?.collectionView.alpha = 1
                self?.consTableView.constant = 641
                self?.consUpView.constant = 141
                self?.topVieW.round(20)
                self?.view.layoutIfNeeded()
            }
        }
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("\(indexPath)")
    }
    
    
    
    
    @IBOutlet weak var topVieW: UIView!
    var viewmodel = ViewModel()
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var consUpView: NSLayoutConstraint!
    @IBOutlet weak var consTableView: NSLayoutConstraint!
    @IBOutlet weak var navBar1: UINavigationItem!
    @IBOutlet weak var rankingTable: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        viewmodel.getRankingFromApi()
        viewmodel.rankingData.bind{
            data in
            print("ranking data:",data)
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
        topVieW.round(20)
    
        
        
        let RankingNib = UINib(nibName: "RankingHeader", bundle: nil)
        rankingTable.register(RankingNib, forHeaderFooterViewReuseIdentifier: "RankingHeader")
        navBar1.backBarButtonItem?.tintColor = UIColor.white
        let nib = UINib(nibName: "RankingTableViewCell", bundle: nil)
        rankingTable.register(nib, forCellReuseIdentifier: "rankingCell")
        rankingTable.delegate = self
        rankingTable.dataSource = self
        if !NetCh.shared.isInternetAvailable() {
            let alert = UIAlertController(title: "No Internet Connection",
                                          message: "Please check your internet connection and restart CricTracker.",
                                          preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
            // Do any additional setup after loading the view.
        }
    }
        
        
        
        
    }

