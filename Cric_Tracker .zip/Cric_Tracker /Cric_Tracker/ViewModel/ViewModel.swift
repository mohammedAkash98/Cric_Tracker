//
//  ViewModel.swift
//  Cric_Tracker
//
//  Created by BJIT on 13/2/23.
//

import Foundation


class ViewModel {
    @Published var lineUp : [LineupElement]?
    var matchData: ObservableObject<RecentMatch?> = ObservableObject(nil)
    var upcomingMatchData: ObservableObject<UpcomingMatch?> = ObservableObject(nil)
    var upcomingMatchDataById: ObservableObject<UpcomingMatchesbyID?> = ObservableObject(nil)
    var scoreBoardData: ObservableObject<ScoreBoardModel?> = ObservableObject(nil)
    var rankingData: ObservableObject<RankingModel?> = ObservableObject(nil)
    var squadData: ObservableObject<SquadModel?> = ObservableObject(nil)
    var playerData: ObservableObject<PlayerModel?> = ObservableObject(nil)
    var careerPlayers: ObservableObject<CareerDataModel?> = ObservableObject(nil)
    static var scoreBoardData: MatchData1?
    static var rcvData: MatchData?
    
   
    func getDataFromApi() {
        APICaller.shared.getRecentMatch { [weak self] data in
            dump(data)
            self?.matchData.value = data
        }
        
        
        
    }
    func getPlayersCareerFromApi(id: Int)
    {
        
        
        print("player id:",id)
        APICaller.shared.getCareerById(id: id){  [weak self] data in
            
            self?.careerPlayers.value = data
            print("Player data:", data?.data?.fullname)
            
            
        }
    }
        func getPlayersFromApi(){
            APICaller.shared.getPlayers{ [weak self] data in
                self?.playerData.value = data
                CoreDataManager.shared.addData(data: data!)
                
                
            }
        }
        func getUpcomingDataFromApi(){
            APICaller.shared.upcomingMatches { [weak self] data in
                self?.upcomingMatchData.value = data
            }
        }
        //    func getSquadFromApi(){
        //        APICaller.shared.getMatchSquad{
        //            data in
        //            self.squadData.value = data
        //        }
        //    }
        func getRankingFromApi() {
            APICaller.shared.getRanking { [weak self] data in
                //print(data)
                self?.rankingData.value = data
            }
        }
        func getUpcomingDataFromApi(id: Int)
        {
            print("check getUpcomingDataFromApi()")
            APICaller.shared.getUpcomingMatchById(id: id){  [weak self] data in
                
                self?.upcomingMatchDataById.value = data
                
                
                
            }
            
        }
    }

