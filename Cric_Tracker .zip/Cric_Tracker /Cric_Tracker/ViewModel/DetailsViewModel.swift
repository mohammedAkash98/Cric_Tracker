//
//  DetailsViewModel.swift
//  Cric_Tracker
//
//  Created by BJIT on 16/2/23.
//

import Foundation
class DetailsViewModel{
    var detailData : UpcomingMatchData
    var homeTFlags: URL?
    var visitorFlags: URL?
    var homeTName: String
    var visitorTName: String
    
    init(details: UpcomingMatchData){
        self.detailData = details
        self.homeTName = details.localteam?.name ?? ""
        self.visitorTName = details.visitorteam?.name ?? ""
        
    }
    
    
}
