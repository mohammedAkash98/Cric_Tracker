//
//  ViewExtension.swift
//  Cric_Tracker
//
//  Created by BJIT on 13/2/23.
//

import Foundation
import UIKit
extension UIView {
    func round(_ radious: CGFloat = 10) {
        DispatchQueue.main.async { [self] in
            layer.cornerRadius = radious
            clipsToBounds = true
        }
        
        
    }

    func addBorder(color: UIColor, width: CGFloat) {
        layer.borderColor = color.cgColor
        layer.borderWidth = width
    }
}
