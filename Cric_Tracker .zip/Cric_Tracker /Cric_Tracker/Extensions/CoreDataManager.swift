//
//  CoreDataManager.swift
//  Cric_Tracker
//
//  Created by BJIT on 23/2/23.
//

import Foundation
import UIKit
import CoreData
class CoreDataManager{
    static let shared = CoreDataManager()
    private init(){}
    var models = [PlayerCoreData]()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    func addData(data: PlayerModel) {

            var dataArray = [[String: Any]]()
        for val in (data.data ?? []) {
                if let id = val.id,
                   let fullName = val.fullname,
                   let imgage_path = val.image_path, let dateofbirth = val.dateofbirth,
                   let battingstyle = val.battingstyle, let bowlingstyle = val.bowlingstyle{
                    let dict: [String: Any] = ["id": Int64(id)
                                               , "fullName": fullName, "image": imgage_path, "dateofbirth": dateofbirth, "battingstyle": battingstyle, "bowlingstyle": bowlingstyle]
                    dataArray.append(dict)
                }
            }
            let batchInsert = NSBatchInsertRequest(entity: PlayerCoreData.entity(), objects: dataArray)
            do {
                let result = try context.execute(batchInsert) as? NSBatchInsertResult
                print("newPrint")
            } catch {
                print(error)
            }
        }
    func getPlayersBySearch( search: String) -> [PlayerCoreData]?  {
        do{
            let fetchRequest = NSFetchRequest<PlayerCoreData>(entityName: "PlayerCoreData")
            
            let predicate = NSPredicate(format: "fullName CONTAINS [cdef] %@", search)
            fetchRequest.predicate = predicate
            //fetchRequest.fetchOffset = 500
            
            let modelssss = try context.fetch(fetchRequest)
            models = modelssss
            return modelssss
        } catch{
            print(error)
            return nil
        }
        
    }
}
