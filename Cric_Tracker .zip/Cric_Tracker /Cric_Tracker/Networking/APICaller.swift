//
//  APICaller.swift
//  Cric_Tracker
//
//  Created by BJIT on 13/2/23.
//

import Foundation

class APICaller {
    static let shared = APICaller()
        private init(){}
    
    
        
    
    
        func getRecentMatch(completion: @escaping (RecentMatch?) -> ()) {
            
            // Fire the request to API
            
            // Create a string URL
            let stringURL = "https://cricket.sportmonks.com/api/v2.0/fixtures?api_token=ReLUDQUOC8sbOBjgIoH6XWGhpFzFYognoQ3wcI7iY1pgtv6Bvgexd7QbXQij&filter%5Bstatus%5D=Finished&sort=-starting_at&fields%5Bteams%5D=name,image_path,code&fields%5Bleagues%5D=name,code&fields%5Bbattings%5D=team_id,ball,score,four_x,six_x&fields%5Bplayers%5D=id,fullname,image_path,dateofbirth&include=localteam,visitorteam,runs,venue,league,lineup,tosswon,manofmatch,batting,batting.batsman,bowling,bowling.bowler&fields%5Bvenues%5D=name,image_path&fields%5Bbowlings%5D=team_id,overs,medians,runs,wickets&fields%5Bfixtures%5D=id,round,localteam_id,visitorteam_id,status,type,note,elected,starting_at"
            //g8HVKlTT1TfZ3UAFwLDT2DuYY37CV0u2RWtEAKPt6J7WfQSSVYdvudtAxWAi
            //,venue,league,lineup,tosswon,manofmatch,batting,batting.batsman,bowling,bowling.bowler
        //https://cricket.sportmonks.com/api/v2.0/fixtures?api_token=h0J6t9SxB02l6U0nRmOiagSZmymozNYQ7GFaTAwmiJ5gSFwIDUC3JJpjtwg7&fields[status]=Finished&include=localteam,visitorteam,runs,venueleague,scoreboards,season,tosswon,venue&sort=starting_at&fields%5Bteams%5D=name,image_path,code&fields%5Bleagues%5D=name,code
        
            //api_token=g8HVKlTT1TfZ3UAFwLDT2DuYY37CV0u2RWtEAKPt6J7WfQSSVYdvudtAxWAi&
                
            // Create URL object
            let url =  URL(string: stringURL)
                
            // Check that URL was created
            guard url != nil else {
                print("Could not create URL")
                return
            }
                
            // Get the URL session
            let session = URLSession.shared
                
            // Create a data task
            let dataTask = session.dataTask(with: url!) { data, response, error in
                
                if error == nil && data != nil {
                    
                    // Parse the returned JSON into article instances
                   
                    let decoder = JSONDecoder()
                    do {
                        let recentMatch = try decoder.decode(RecentMatch.self, from: data!)
                        
                        completion(recentMatch)
                    } catch {
                        print(error)
                    }
                }
                else {
                    print(error)
                }
            }
                
            // Start the data task
            dataTask.resume()
        }
    func getRanking(completion: @escaping (RankingModel?) -> ()) {
        
        // Fire the request to API
        
        // Create a string URL
        let stringURL = "https://cricket.sportmonks.com/api/v2.0/team-rankings?api_token=ReLUDQUOC8sbOBjgIoH6XWGhpFzFYognoQ3wcI7iY1pgtv6Bvgexd7QbXQij&include=teams"
            
        // Create URL object
        let url =  URL(string: stringURL)
            
        // Check that URL was created
        guard url != nil else {
            print("Could not create URL")
            return
        }
        
       
            
            
        // Get the URL session
        let session = URLSession.shared
            
        // Create a data task
        let dataTask = session.dataTask(with: url!) { data, response, error in
            
            if error == nil && data != nil {
                
                // Parse the returned JSON into article instances
                
                let decoder = JSONDecoder()
                do {
                    let recentMatch = try decoder.decode(RankingModel.self, from: data!)
                    //dump(articleService)
                    //dump(recentMatch.data?[0].localteam)
                    completion(recentMatch)
                    
                    


                } catch {
                    print("Could not decode the json data")
                }
            }
            else {
                print("Error creating dataTask")
            }
        }
            
        // Start the data task
        dataTask.resume()
    }
    func getCareerById(id: Int, completion: @escaping (CareerDataModel?) -> ()){
        
        // Fire the request to API
        
        print("Player id form getCareerById:", id)
        
        // Create a string URL
        let stringURL = "https://cricket.sportmonks.com/api/v2.0/players/\(id)?include=career&api_token=lSCiYynw4Q4kdiPGZzWQt5VEPYSkGWN3lUXTdOATLwIog64ffRYsPFgZkerD"
        
        
   
        


            
        // Create URL object
        let url =  URL(string: stringURL)
            
      
        // Check that URL was created
        guard url != nil else {
            print("Could not create URL")
            return
        }
        
       
            
            
        // Get the URL session
        let session = URLSession.shared
            
        // Create a data task
        let dataTask = session.dataTask(with: url!) { data, response, error in
            
            if error == nil && data != nil {
                
                // Parse the returned JSON into article instances
                
                let decoder = JSONDecoder()
                do {
                    
                    //print("data:",data!)
                    let upcomingMatch = try decoder.decode(CareerDataModel.self, from: data!)
//                    print("dump upcoming data from API response")
//                    dump(upcomingMatch)
                    completion(upcomingMatch)
                    
                    


                } catch {
                    print("Could not decode the json data upcoming")
                }
            }
            else {
                print("Error creating dataTask")
            }
        }
            
        // Start the data task
        dataTask.resume()
        
    }
    
    func getPlayers(completion: @escaping (PlayerModel?) -> ()) {
        CoreDataManager.shared.getPlayersBySearch(search: "")
        // Fire the request to API
//        if CoreDataManager.shared.models.count == 0{
            let stringURL = "https://cricket.sportmonks.com/api/v2.0/players?api_token=ReLUDQUOC8sbOBjgIoH6XWGhpFzFYognoQ3wcI7iY1pgtv6Bvgexd7QbXQij&fields%5Bplayers%5D=id,fullname,image_path,dateofbirth,battingstyle,bowlingstyle"
            let url =  URL(string: stringURL)
                
            // Check that URL was created
            guard url != nil else {
                print("Could not create URL")
                return
            }
            
           
                
                
            // Get the URL session
            let session = URLSession.shared
                
            // Create a data task
            let dataTask = session.dataTask(with: url!) { data, response, error in
                
                if error == nil && data != nil {
                    
                    // Parse the returned JSON into article instances
                    
                    let decoder = JSONDecoder()
                    do {
                        let players = try decoder.decode(PlayerModel.self, from: data!)
//                       
                        completion(players)
                        
                        


                    } catch {
                        print(error)
                    }
                }
                else {
                    print("Error creating dataTask")
                }
            }
                
            // Start the data task
            dataTask.resume()
        
//        else {
//            CoreDataManager.shared.models
//        }
        }
        
        // Create a string URL
        
            
        // Create URL object
        
    
    
    func getUpcomingMatchById(id: Int, completion: @escaping (UpcomingMatchesbyID?) -> ()){
        
        // Fire the request to API
        
        // Create a string URL
        let stringURL = "https://cricket.sportmonks.com/api/v2.0/fixtures/\(id)?api_token=g8HVKlTT1TfZ3UAFwLDT2DuYY37CV0u2RWtEAKPt6J7WfQSSVYdvudtAxWAi&filter%5Bstatus%5D=NS&include=runs,localteam,visitorteam,venue&sort=starting_at&fields%5Bteams%5D=name,image_path,code"
        
        
//        let stringURL = "https://cricket.sportmonks.com/api/v2.0/fixtures?api_token=lSCiYynw4Q4kdiPGZzWQt5VEPYSkGWN3lUXTdOATLwIog64ffRYsPFgZkerD&filter%5Bstatus%5D=NS&include=runs,localteam,visitorteam,venue&sort=starting_at&fields%5Bteams%5D=name,image_path,code"

            
        // Create URL object
        let url =  URL(string: stringURL)
            
        print("upcoming match by id URL:", url)
        // Check that URL was created
        guard url != nil else {
            print("Could not create URL")
            return
        }
        
       
            
            
        // Get the URL session
        let session = URLSession.shared
            
        // Create a data task
        let dataTask = session.dataTask(with: url!) { data, response, error in
            
            if error == nil && data != nil {
                
                // Parse the returned JSON into article instances
                
                let decoder = JSONDecoder()
                do {
                    
                    print("data:",data!)
                    let upcomingMatch = try decoder.decode(UpcomingMatchesbyID.self, from: data!)
//                    print("dump upcoming data from API response")
//                    dump(upcomingMatch)
                    completion(upcomingMatch)
                    
                    


                } catch {
                    print("Could not decode the json data upcoming")
                }
            }
            else {
                print("Error creating dataTask")
            }
        }
            
        // Start the data task
        dataTask.resume()
        
    }
    func upcomingMatches(completion: @escaping (UpcomingMatch?) -> ()) {
        
        // Fire the request to API
        
        // Create a string URL
        let stringURL = "https://cricket.sportmonks.com/api/v2.0/fixtures?api_token=ReLUDQUOC8sbOBjgIoH6XWGhpFzFYognoQ3wcI7iY1pgtv6Bvgexd7QbXQij&filter%5Bstatus%5D=NS&include=localteam,visitorteam,runs,venue,league,manofmatch&sort=starting_at&fields%5Bteams%5D=name,image_path,code&fields%5Bleagues%5D=name,code"
        
        //api_token=5NuV3bPUD19jQW1kINP3QwPYqtZPeHKiA55CjjI4QPRLgwAdg6IdfG2N09Ze&
            
        // Create URL object
        let url =  URL(string: stringURL)
            
        // Check that URL was created
        guard url != nil else {
            print("Could not create URL")
            return
        }
            
        // Get the URL session
        let session = URLSession.shared
            
        // Create a data task
        let dataTask = session.dataTask(with: url!) { data, response, error in
            
            if error == nil && data != nil {
                
                // Parse the returned JSON into article instances
               
                let decoder = JSONDecoder()
                decoder.dateDecodingStrategy = .iso8601
                do {
                    let upcomingMatch = try decoder.decode(UpcomingMatch.self, from: data!)
                    
                    //debugPrint(upcomingMatch)
                    completion(upcomingMatch)
                } catch {
                    print("Could not decode the json data")
                }
            }
            else {
                print("Error creating dataTask")
            }
        }
            
        // Start the data task
        dataTask.resume()
    }
        
        
        
        
    }
