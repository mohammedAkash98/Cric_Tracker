//
//  PlayerCoreData+CoreDataClass.swift
//  Cric_Tracker
//
//  Created by BJIT on 24/2/23.
//
//

import Foundation
import CoreData

@objc(PlayerCoreData)
public class PlayerCoreData: NSManagedObject {

}
